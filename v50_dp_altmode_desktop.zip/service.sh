#!/system/bin/sh
# ==============================================================================
# service.sh - NEUTERED / SAFEGUARDED (Milestone 2 Architecture)
#
# CRITICAL SAFETY NOTICE:
# Early boot SBU / VCONN / DRM manipulation is strictly prohibited on LG V50.
# Boot-time overrides previously triggered:
#   1. vendor.lineage.livedisplay@2.1-service.lge_msmnile SIGABRT crashloop -> Magisk Safe Mode.
#   2. PM8150B PMIC hardware hard reboot (overcurrent / VBUS collision when plugged into PC).
#
# In accordance with Milestone 2 safety requirements, all screen mirroring
# controls MUST be executed post-boot at runtime via:
#   /data/local/tmp/v50_safe_mirror.sh
# ==============================================================================

LOGFILE="/data/local/tmp/v50_magisk_boot.log"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] [SAFEGUARD] Boot-time SBU/VCONN overrides are disabled for hardware safety." >> "$LOGFILE"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] [SAFEGUARD] Use runtime command: /data/local/tmp/v50_safe_mirror.sh start|status" >> "$LOGFILE"

exit 0
