#!/system/bin/sh
# ==============================================================================
# service.sh - Magisk Late-Start Boot Service for LG V50 DisplayPort & Desktop Mode
# Target Device: LG V50 ThinQ 5G (LM-V500 / flashlmdd, Snapdragon 855 SM8150)
# Environment: LineageOS 20 (Android 13) / Shark Kernel 4.14.215 / Magisk 26+ / 30+
# ==============================================================================

MODDIR=${0%/*}
LOGFILE="/data/local/tmp/v50_magisk_boot.log"

log() {
    local ts=$(date "+%Y-%m-%d %H:%M:%S" 2>/dev/null || echo "boot")
    echo "[$ts] $*" >> "$LOGFILE"
}

log "=== LG V50 DP Alt Mode & Desktop Service Initializing ==="

# Wait until system boot is completely finished
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 3
done

# Wait for settings provider to stabilize
sleep 2
log "[+] Android boot completed. Proceeding with configuration..."

# ------------------------------------------------------------------------------
# 1. Configure AOSP Desktop Mode & Freeform Windowing
# ------------------------------------------------------------------------------
log "[*] Configuring AOSP Desktop Mode global settings..."
settings put global development_settings_enabled 1 2>/dev/null
settings put global force_desktop_mode_on_external_displays 1 2>/dev/null
settings put global enable_freeform_support 1 2>/dev/null
settings put global force_allow_on_external 1 2>/dev/null
settings put global enable_non_resizable_multi_window 1 2>/dev/null

setprop persist.sys.desktop_mode 1 2>/dev/null
setprop persist.sys.freeform_support 1 2>/dev/null
setprop persist.sys.multiwindow.enable 1 2>/dev/null
log "[+] Desktop Mode settings configured successfully."

# ------------------------------------------------------------------------------
# 2. Hardware SBU Switch Override (GPIO 119 = 1, GPIO 87 = Polarity)
# ------------------------------------------------------------------------------
GPIO_OE=119
GPIO_SEL=87
SBU_DEV="vendor:lge_sbu_switch"
SBU_DRV="/sys/bus/platform/drivers/lge_sbu_switch"
OTG_DIR="/sys/class/usbpd/usbpd0/otg_default"
DRM_DP="/sys/class/drm/card0-DP-1"

# Unbind driver if bound
if [ -L "$SBU_DRV/$SBU_DEV" ]; then
    log "[*] Unbinding $SBU_DEV from kernel driver..."
    echo "$SBU_DEV" > "$SBU_DRV/unbind" 2>/dev/null
fi

# Export GPIOs
for pin in $GPIO_OE $GPIO_SEL; do
    if [ ! -d "/sys/class/gpio/gpio$pin" ]; then
        echo "$pin" > /sys/class/gpio/export 2>/dev/null
    fi
done

# Determine initial polarity
pol=0
cc1=$(cat "$OTG_DIR/cc1" 2>/dev/null || echo "Open")
cc2=$(cat "$OTG_DIR/cc2" 2>/dev/null || echo "Open")
if [ "$cc2" != "Open" ] && [ "$cc1" = "Open" ]; then
    pol=1
fi

# Set direction and initial values
if [ -d "/sys/class/gpio/gpio$GPIO_OE" ]; then
    echo "out" > "/sys/class/gpio/gpio$GPIO_OE/direction" 2>/dev/null
    echo 1 > "/sys/class/gpio/gpio$GPIO_OE/value" 2>/dev/null
    log "[+] SBU OE (GPIO 119) asserted to 1 (AUX differential pairs connected)."
fi

if [ -d "/sys/class/gpio/gpio$GPIO_SEL" ]; then
    echo "out" > "/sys/class/gpio/gpio$GPIO_SEL/direction" 2>/dev/null
    echo "$pol" > "/sys/class/gpio/gpio$GPIO_SEL/value" 2>/dev/null
    log "[+] SBU SEL (GPIO 87) set to $pol (Orientation: $([ "$pol" = "1" ] && echo 'CC2 Reversed' || echo 'CC1 Normal'))."
fi

# Assert VCONN supply
if [ -w "$OTG_DIR/powers_vconn" ]; then
    echo y > "$OTG_DIR/powers_vconn" 2>/dev/null
    log "[+] VCONN power enabled."
fi

# Trigger DRM detection
if [ -w "$DRM_DP/status" ]; then
    echo detect > "$DRM_DP/status" 2>/dev/null
    log "[+] DRM connector detect triggered."
fi

# ------------------------------------------------------------------------------
# 3. Launch Persistent Hotplug Daemon
# ------------------------------------------------------------------------------
# If standalone script exists, launch it in daemon mode; otherwise run inline loop
if [ -f "/data/local/tmp/enable_dp_altmode.sh" ]; then
    log "[*] Spawning /data/local/tmp/enable_dp_altmode.sh --daemon..."
    /data/local/tmp/enable_dp_altmode.sh --daemon >> "$LOGFILE" 2>&1 &
elif [ -f "$MODDIR/scripts/enable_dp_altmode.sh" ]; then
    log "[*] Spawning $MODDIR/scripts/enable_dp_altmode.sh --daemon..."
    "$MODDIR/scripts/enable_dp_altmode.sh" --daemon >> "$LOGFILE" 2>&1 &
else
    # Inline lightweight monitor loop
    log "[*] Starting inline hotplug background monitor loop..."
    (
        last_pol=$pol
        while true; do
            sleep 3
            # Ensure GPIO 119 stays asserted
            if [ -d "/sys/class/gpio/gpio$GPIO_OE" ]; then
                echo 1 > "/sys/class/gpio/gpio$GPIO_OE/value" 2>/dev/null
            fi
            # Check polarity
            curr_cc1=$(cat "$OTG_DIR/cc1" 2>/dev/null || echo "Open")
            curr_cc2=$(cat "$OTG_DIR/cc2" 2>/dev/null || echo "Open")
            curr_pol=0
            if [ "$curr_cc2" != "Open" ] && [ "$curr_cc1" = "Open" ]; then
                curr_pol=1
            fi
            if [ "$curr_pol" != "$last_pol" ]; then
                if [ -d "/sys/class/gpio/gpio$GPIO_SEL" ]; then
                    echo "$curr_pol" > "/sys/class/gpio/gpio$GPIO_SEL/value" 2>/dev/null
                fi
                last_pol=$curr_pol
                echo y > "$OTG_DIR/powers_vconn" 2>/dev/null
                echo detect > "$DRM_DP/status" 2>/dev/null
            fi
        done
    ) &
fi

log "=== LG V50 DP Alt Mode & Desktop Boot Setup Finished ==="
exit 0
